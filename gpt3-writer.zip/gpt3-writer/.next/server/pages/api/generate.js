"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/generate";
exports.ids = ["pages/api/generate"];
exports.modules = {

/***/ "openai":
/*!*************************!*\
  !*** external "openai" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("openai");

/***/ }),

/***/ "(api)/./pages/api/generate.js":
/*!*******************************!*\
  !*** ./pages/api/generate.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! openai */ \"openai\");\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_0__);\n\nconst configuration = new openai__WEBPACK_IMPORTED_MODULE_0__.Configuration({\n    apiKey: process.env.OPENAI_API_KEY\n});\nconst openai = new openai__WEBPACK_IMPORTED_MODULE_0__.OpenAIApi(configuration);\nconst basePromptPrefix = `Write me a table of contents for the title below .  \nTitle:\n`;\nconst generateAction = async (req, res)=>{\n    console.log(`API: ${basePromptPrefix}${req.body.userInput}`);\n    // Run first prompt\n    const baseCompletion = await openai.createCompletion({\n        model: \"text-davinci-003\",\n        prompt: `${basePromptPrefix}${req.body.userInput}`,\n        temperature: 0.7,\n        max_tokens: 500\n    });\n    const basePromptOutput = baseCompletion.data.choices.pop();\n    console.log(JSON.stringify(`${basePromptOutput}`), \"this is base Prompt Output\");\n    //Prompt #2\n    const secondPrompt = `\n  Take the title of contents from ${basePromptOutput} and generate a detailed thread explaining with examples. Make it feel like a story. Don't just list the points. Go deep into each line. Explain why with examples.   \n  Title: \"The title as follows:\"\n   \n  Query Summary:\n  `;\n    //I call the openAI API second time with Prompt #2\n    const secondPromptCompletion = await openai.createCompletion({\n        model: \"text-davinci-003\",\n        prompt: `${secondPrompt}`,\n        temperature: 0.80,\n        max_tokens: 1000\n    });\n    //get Output\n    const secondPromptOutput = secondPromptCompletion.data.choices.pop();\n    console.log(`${secondPromptOutput.text}`, \"this is second Prompt Output\");\n    res.status(200).json(JSON.stringify({\n        output: {\n            contents: basePromptOutput,\n            blog: secondPromptOutput\n        }\n    }));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (generateAction);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2VuZXJhdGUuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWtEO0FBRWxELE1BQU1FLGdCQUFnQixJQUFJRixpREFBYUEsQ0FBQztJQUN0Q0csUUFBUUMsUUFBUUMsR0FBRyxDQUFDQyxjQUFjO0FBQ3BDO0FBRUEsTUFBTUMsU0FBUyxJQUFJTiw2Q0FBU0EsQ0FBQ0M7QUFFN0IsTUFBTU0sbUJBQW1CLENBQUM7O0FBRTFCLENBQUM7QUFDRCxNQUFNQyxpQkFBaUIsT0FBT0MsS0FBS0MsTUFBUTtJQUN6Q0MsUUFBUUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFTCxpQkFBaUIsRUFBRUUsSUFBSUksSUFBSSxDQUFDQyxTQUFTLENBQUMsQ0FBQztJQUMzRCxtQkFBbUI7SUFDbkIsTUFBTUMsaUJBQWlCLE1BQU1ULE9BQU9VLGdCQUFnQixDQUFDO1FBQ25EQyxPQUFPO1FBQ1BDLFFBQVEsQ0FBQyxFQUFFWCxpQkFBaUIsRUFBRUUsSUFBSUksSUFBSSxDQUFDQyxTQUFTLENBQUMsQ0FBQztRQUNsREssYUFBYTtRQUNiQyxZQUFZO0lBQ2Q7SUFFQSxNQUFNQyxtQkFBbUJOLGVBQWVPLElBQUksQ0FBQ0MsT0FBTyxDQUFDQyxHQUFHO0lBQ3hEYixRQUFRQyxHQUFHLENBQUNhLEtBQUtDLFNBQVMsQ0FBQyxDQUFDLEVBQUVMLGlCQUFpQixDQUFDLEdBQUc7SUFFbkQsV0FBVztJQUVYLE1BQU1NLGVBQ04sQ0FBQztrQ0FDK0IsRUFBRU4saUJBQWlCOzs7O0VBSW5ELENBQUM7SUFFRCxrREFBa0Q7SUFDbEQsTUFBTU8seUJBQXlCLE1BQU10QixPQUFPVSxnQkFBZ0IsQ0FBQztRQUMzREMsT0FBTztRQUNQQyxRQUFRLENBQUMsRUFBRVMsYUFBYSxDQUFDO1FBQ3pCUixhQUFhO1FBQ2JDLFlBQVk7SUFDZDtJQUVBLFlBQVk7SUFDWixNQUFNUyxxQkFBcUJELHVCQUF1Qk4sSUFBSSxDQUFDQyxPQUFPLENBQUNDLEdBQUc7SUFDbEViLFFBQVFDLEdBQUcsQ0FBQyxDQUFDLEVBQUVpQixtQkFBbUJDLElBQUksQ0FBQyxDQUFDLEVBQUU7SUFFMUNwQixJQUFJcUIsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQ1AsS0FBS0MsU0FBUyxDQUFDO1FBQUVPLFFBQVE7WUFBQ0MsVUFBVWI7WUFBa0JjLE1BQU1OO1FBQW1CO0lBQUM7QUFDdkc7QUFFQSxpRUFBZXJCLGNBQWNBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zY3JhdGNocGFkLy4vcGFnZXMvYXBpL2dlbmVyYXRlLmpzPzYyN2MiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29uZmlndXJhdGlvbiwgT3BlbkFJQXBpIH0gZnJvbSAnb3BlbmFpJztcblxuY29uc3QgY29uZmlndXJhdGlvbiA9IG5ldyBDb25maWd1cmF0aW9uKHtcbiAgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSxcbn0pO1xuXG5jb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJQXBpKGNvbmZpZ3VyYXRpb24pO1xuXG5jb25zdCBiYXNlUHJvbXB0UHJlZml4ID0gYFdyaXRlIG1lIGEgdGFibGUgb2YgY29udGVudHMgZm9yIHRoZSB0aXRsZSBiZWxvdyAuICBcblRpdGxlOlxuYDtcbmNvbnN0IGdlbmVyYXRlQWN0aW9uID0gYXN5bmMgKHJlcSwgcmVzKSA9PiB7XG4gIGNvbnNvbGUubG9nKGBBUEk6ICR7YmFzZVByb21wdFByZWZpeH0ke3JlcS5ib2R5LnVzZXJJbnB1dH1gKVxuICAvLyBSdW4gZmlyc3QgcHJvbXB0XG4gIGNvbnN0IGJhc2VDb21wbGV0aW9uID0gYXdhaXQgb3BlbmFpLmNyZWF0ZUNvbXBsZXRpb24oe1xuICAgIG1vZGVsOiAndGV4dC1kYXZpbmNpLTAwMycsXG4gICAgcHJvbXB0OiBgJHtiYXNlUHJvbXB0UHJlZml4fSR7cmVxLmJvZHkudXNlcklucHV0fWAsXG4gICAgdGVtcGVyYXR1cmU6IDAuNyxcbiAgICBtYXhfdG9rZW5zOiA1MDAsXG4gIH0pO1xuICBcbiAgY29uc3QgYmFzZVByb21wdE91dHB1dCA9IGJhc2VDb21wbGV0aW9uLmRhdGEuY2hvaWNlcy5wb3AoKTtcbiAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoYCR7YmFzZVByb21wdE91dHB1dH1gKSwgXCJ0aGlzIGlzIGJhc2UgUHJvbXB0IE91dHB1dFwiKTtcblxuICAvL1Byb21wdCAjMlxuXG4gIGNvbnN0IHNlY29uZFByb21wdCA9IFxuICBgXG4gIFRha2UgdGhlIHRpdGxlIG9mIGNvbnRlbnRzIGZyb20gJHtiYXNlUHJvbXB0T3V0cHV0fSBhbmQgZ2VuZXJhdGUgYSBkZXRhaWxlZCB0aHJlYWQgZXhwbGFpbmluZyB3aXRoIGV4YW1wbGVzLiBNYWtlIGl0IGZlZWwgbGlrZSBhIHN0b3J5LiBEb24ndCBqdXN0IGxpc3QgdGhlIHBvaW50cy4gR28gZGVlcCBpbnRvIGVhY2ggbGluZS4gRXhwbGFpbiB3aHkgd2l0aCBleGFtcGxlcy4gICBcbiAgVGl0bGU6IFwiVGhlIHRpdGxlIGFzIGZvbGxvd3M6XCJcbiAgIFxuICBRdWVyeSBTdW1tYXJ5OlxuICBgXG5cbiAgLy9JIGNhbGwgdGhlIG9wZW5BSSBBUEkgc2Vjb25kIHRpbWUgd2l0aCBQcm9tcHQgIzJcbiAgY29uc3Qgc2Vjb25kUHJvbXB0Q29tcGxldGlvbiA9IGF3YWl0IG9wZW5haS5jcmVhdGVDb21wbGV0aW9uKHtcbiAgICBtb2RlbDogJ3RleHQtZGF2aW5jaS0wMDMnLFxuICAgIHByb21wdDogYCR7c2Vjb25kUHJvbXB0fWAsXG4gICAgdGVtcGVyYXR1cmU6IDAuODAsXG4gICAgbWF4X3Rva2VuczogMTAwMCxcbiAgfSk7XG5cbiAgLy9nZXQgT3V0cHV0XG4gIGNvbnN0IHNlY29uZFByb21wdE91dHB1dCA9IHNlY29uZFByb21wdENvbXBsZXRpb24uZGF0YS5jaG9pY2VzLnBvcCgpO1xuICBjb25zb2xlLmxvZyhgJHtzZWNvbmRQcm9tcHRPdXRwdXQudGV4dH1gLCBcInRoaXMgaXMgc2Vjb25kIFByb21wdCBPdXRwdXRcIik7XG5cbiAgcmVzLnN0YXR1cygyMDApLmpzb24oSlNPTi5zdHJpbmdpZnkoeyBvdXRwdXQ6IHtjb250ZW50czogYmFzZVByb21wdE91dHB1dCwgYmxvZzogc2Vjb25kUHJvbXB0T3V0cHV0IH19KSk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBnZW5lcmF0ZUFjdGlvbjsiXSwibmFtZXMiOlsiQ29uZmlndXJhdGlvbiIsIk9wZW5BSUFwaSIsImNvbmZpZ3VyYXRpb24iLCJhcGlLZXkiLCJwcm9jZXNzIiwiZW52IiwiT1BFTkFJX0FQSV9LRVkiLCJvcGVuYWkiLCJiYXNlUHJvbXB0UHJlZml4IiwiZ2VuZXJhdGVBY3Rpb24iLCJyZXEiLCJyZXMiLCJjb25zb2xlIiwibG9nIiwiYm9keSIsInVzZXJJbnB1dCIsImJhc2VDb21wbGV0aW9uIiwiY3JlYXRlQ29tcGxldGlvbiIsIm1vZGVsIiwicHJvbXB0IiwidGVtcGVyYXR1cmUiLCJtYXhfdG9rZW5zIiwiYmFzZVByb21wdE91dHB1dCIsImRhdGEiLCJjaG9pY2VzIiwicG9wIiwiSlNPTiIsInN0cmluZ2lmeSIsInNlY29uZFByb21wdCIsInNlY29uZFByb21wdENvbXBsZXRpb24iLCJzZWNvbmRQcm9tcHRPdXRwdXQiLCJ0ZXh0Iiwic3RhdHVzIiwianNvbiIsIm91dHB1dCIsImNvbnRlbnRzIiwiYmxvZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/generate.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/generate.js"));
module.exports = __webpack_exports__;

})();